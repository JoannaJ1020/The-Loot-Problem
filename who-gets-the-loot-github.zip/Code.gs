/**
 * WHO GETS THE LOOT?
 * Google Apps Script backend for a Google Sheets database.
 *
 * DEPLOYMENT:
 * 1) Create a Google Sheet.
 * 2) Open Extensions > Apps Script.
 * 3) Replace the default code with this file.
 * 4) Run setupDatabase() once and authorize it.
 * 5) Deploy > New deployment > Web app.
 *    Execute as: Me
 *    Who has access: Anyone
 *
 * This project intentionally uses:
 * - SpreadsheetApp.getActiveSpreadsheet()
 * - Content-Type text/plain JSON requests from the frontend
 * - LockService for shared writes
 * - Incremental contribution updates (never replacement totals)
 */

// ============================================================
// CONFIG
// ============================================================

const SHEETS = {
  SESSIONS: 'Sessions',
  PLAYERS: 'Players',
  VOTES: 'Votes',
  RESULTS: 'Results'
};

const HEADERS = {
  Sessions: [
    'Session_ID',
    'Phase',
    'Created_Time',
    'Start_Time',
    'Boss_HP',
    'Raid_HP',
    'Raid_Duration'
  ],
  Players: [
    'Session_ID',
    'Player_ID',
    'Role',
    'Joined_Time',
    'Last_Seen',
    'Damage',
    'Healing',
    'Blocked',
    'Actions'
  ],
  Votes: [
    'Session_ID',
    'Player_ID',
    'Loot_Vote',
    'System_Vote',
    'Timestamp'
  ],
  Results: [
    'Session_ID',
    'Player_Count',
    'Total_Damage',
    'Total_Healing',
    'Total_Blocked',
    'Yes_Count',
    'No_Count',
    'Last_Updated'
  ]
};

const PHASES = {
  WAITING: 'WAITING',
  RAID: 'RAID',
  LOOT: 'LOOT',
  RESULTS: 'RESULTS'
};

const ROLES = ['DPS', 'HEALER', 'TANK'];

const GAME = {
  RAID_DURATION_SECONDS: 60,

  // Frontend and backend should use these same values.
  ATTACK_VALUE: 10,
  HEAL_VALUE: 6,
  BLOCK_VALUE: 1,

  // Approximately balances the boss for 15–40 active students.
  // Boss HP is calculated when START RAID is pressed.
  BOSS_HP_PER_PLAYER: 420,
  MIN_BOSS_HP: 3000,

  // Shared raid survivability tuning.
  RAID_HP_PER_PLAYER: 220,
  MIN_RAID_HP: 2500,
  RAID_DAMAGE_PER_PLAYER_PER_SECOND: 5,
  BLOCK_MITIGATION_VALUE: 12,

  // Useful values for the frontend.
  CLICK_COOLDOWN_MS: 250,
  CONTRIBUTION_UPLOAD_MS: 3000,
  STUDENT_POLL_MS: 3500,
  HOST_POLL_MS: 2000
};

const VALID_LOOT_VOTES = ['A', 'B', 'C', 'D', 'E'];
const VALID_SYSTEM_VOTES = ['YES', 'NO'];


// ============================================================
// ONE-TIME SETUP
// ============================================================

function setupDatabase() {
  ensureDatabase_();
  return {
    ok: true,
    message: 'Database is ready.'
  };
}


// ============================================================
// WEB APP ENTRY POINTS
// ============================================================

function doGet(e) {
  try {
    ensureDatabase_();

    const params = (e && e.parameter) ? e.parameter : {};
    const action = String(params.action || '').trim();

    let result;

    switch (action) {
      case 'get_session':
        result = getSession_(params.session_id);
        break;

      case 'get_players':
        result = getPlayers_(params.session_id);
        break;

      case 'get_results':
        result = getResults_(params.session_id);
        break;

      case 'ping':
        result = {
          ok: true,
          message: 'WHO GETS THE LOOT? backend is running.',
          server_time: new Date().toISOString()
        };
        break;

      default:
        throw new Error(
          'Unknown GET action. Supported actions: get_session, get_players, get_results, ping.'
        );
    }

    return jsonResponse_(result);

  } catch (err) {
    return jsonResponse_({
      ok: false,
      error: safeError_(err)
    });
  }
}


function doPost(e) {
  try {
    ensureDatabase_();

    if (!e || !e.postData || !e.postData.contents) {
      throw new Error('Missing POST body.');
    }

    let body;
    try {
      body = JSON.parse(e.postData.contents);
    } catch (parseErr) {
      throw new Error('POST body must contain valid JSON.');
    }

    const action = String(body.action || '').trim();

    let result;

    switch (action) {
      case 'create_session':
        result = createSession_();
        break;

      case 'join_session':
        result = joinSession_(body);
        break;

      case 'start_raid':
        result = startRaid_(body.session_id);
        break;

      case 'update_contribution':
        result = updateContribution_(body);
        break;

      case 'submit_vote':
        result = submitVote_(body);
        break;

      case 'set_phase':
        result = setPhase_(body.session_id, body.phase);
        break;

      case 'reset_session':
        result = resetSession_(body.session_id);
        break;

      default:
        throw new Error(
          'Unknown POST action. Supported actions: create_session, join_session, start_raid, update_contribution, submit_vote, set_phase, reset_session.'
        );
    }

    return jsonResponse_(result);

  } catch (err) {
    return jsonResponse_({
      ok: false,
      error: safeError_(err)
    });
  }
}


// ============================================================
// POST ACTIONS
// ============================================================

function createSession_() {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const sessionsSheet = getSheet_(SHEETS.SESSIONS);
    const sessionId = generateUniqueSessionId_(sessionsSheet);
    const now = new Date();

    sessionsSheet.appendRow([
      sessionId,
      PHASES.WAITING,
      now,
      '',
      0,
      0,
      GAME.RAID_DURATION_SECONDS
    ]);

    upsertResultRow_(sessionId, {
      player_count: 0,
      total_damage: 0,
      total_healing: 0,
      total_blocked: 0,
      yes_count: 0,
      no_count: 0
    });

    return {
      ok: true,
      session_id: sessionId,
      phase: PHASES.WAITING,
      created_time: now.toISOString(),
      raid_duration: GAME.RAID_DURATION_SECONDS,
      game_config: publicGameConfig_()
    };

  } finally {
    lock.releaseLock();
  }
}


function joinSession_(body) {
  const sessionId = normalizeSessionId_(body.session_id);
  const requestedPlayerId = String(body.player_id || '').trim();

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const session = findSessionRecord_(sessionId);
    if (!session) {
      throw new Error('Session not found.');
    }

    const playersSheet = getSheet_(SHEETS.PLAYERS);
    const values = getBodyValues_(playersSheet, HEADERS.Players.length);
    const now = new Date();

    // Graceful refresh/reconnect:
    // If the browser already has a valid Player_ID for this session,
    // return the existing identity instead of assigning a new one.
    if (requestedPlayerId) {
      for (let i = 0; i < values.length; i++) {
        if (
          String(values[i][0]) === sessionId &&
          String(values[i][1]) === requestedPlayerId
        ) {
          const rowNumber = i + 2;
          playersSheet.getRange(rowNumber, 5).setValue(now);

          return {
            ok: true,
            session_id: sessionId,
            player_id: requestedPlayerId,
            role: String(values[i][2]),
            phase: String(session.values[1]),
            rejoined: true,
            players_joined: countPlayersForSessionFromValues_(values, sessionId),
            game_config: publicGameConfig_()
          };
        }
      }
    }

    const phase = String(session.values[1]);
    if (phase === PHASES.LOOT || phase === PHASES.RESULTS) {
      throw new Error('This raid is no longer accepting new players.');
    }

    const playerId = nextPlayerIdFromValues_(values, sessionId);
    const role = chooseBalancedRoleFromValues_(values, sessionId);

    playersSheet.appendRow([
      sessionId,
      playerId,
      role,
      now,
      now,
      0,
      0,
      0,
      0
    ]);

    return {
      ok: true,
      session_id: sessionId,
      player_id: playerId,
      role: role,
      phase: phase,
      rejoined: false,
      players_joined: countPlayersForSessionFromValues_(values, sessionId) + 1,
      game_config: publicGameConfig_()
    };

  } finally {
    lock.releaseLock();
  }
}


function startRaid_(sessionIdRaw) {
  const sessionId = normalizeSessionId_(sessionIdRaw);

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const session = findSessionRecord_(sessionId);
    if (!session) {
      throw new Error('Session not found.');
    }

    const playersSheet = getSheet_(SHEETS.PLAYERS);
    const playerValues = getBodyValues_(playersSheet, HEADERS.Players.length);
    const playerCount = countPlayersForSessionFromValues_(playerValues, sessionId);

    if (playerCount < 1) {
      throw new Error('At least one player must join before the raid can start.');
    }

    const bossMaxHp = Math.max(
      GAME.MIN_BOSS_HP,
      playerCount * GAME.BOSS_HP_PER_PLAYER
    );

    const raidMaxHp = Math.max(
      GAME.MIN_RAID_HP,
      playerCount * GAME.RAID_HP_PER_PLAYER
    );

    const now = new Date();

    const sessionsSheet = getSheet_(SHEETS.SESSIONS);

    // Phase, Start_Time, Boss_HP, Raid_HP, Raid_Duration
    sessionsSheet.getRange(session.row, 2, 1, 6).setValues([[
      PHASES.RAID,
      session.values[2],
      now,
      bossMaxHp,
      raidMaxHp,
      GAME.RAID_DURATION_SECONDS
    ]]);

    return {
      ok: true,
      session_id: sessionId,
      phase: PHASES.RAID,
      start_time: now.toISOString(),
      player_count: playerCount,
      boss_max_hp: bossMaxHp,
      raid_max_hp: raidMaxHp,
      raid_duration: GAME.RAID_DURATION_SECONDS,
      game_config: publicGameConfig_()
    };

  } finally {
    lock.releaseLock();
  }
}


function updateContribution_(body) {
  const sessionId = normalizeSessionId_(body.session_id);
  const playerId = String(body.player_id || '').trim();

  if (!playerId) {
    throw new Error('Missing player_id.');
  }

  const incomingDamage = nonNegativeInteger_(body.damage_delta);
  const incomingHealing = nonNegativeInteger_(body.healing_delta);
  const incomingBlocked = nonNegativeInteger_(body.blocked_delta);
  const incomingActions = nonNegativeInteger_(body.actions_delta);

  if (
    incomingDamage === 0 &&
    incomingHealing === 0 &&
    incomingBlocked === 0 &&
    incomingActions === 0
  ) {
    return {
      ok: true,
      session_id: sessionId,
      player_id: playerId,
      accepted: {
        damage_delta: 0,
        healing_delta: 0,
        blocked_delta: 0,
        actions_delta: 0
      },
      message: 'Nothing to update.'
    };
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const session = findSessionRecord_(sessionId);
    if (!session) {
      throw new Error('Session not found.');
    }

    if (String(session.values[1]) !== PHASES.RAID) {
      throw new Error('Contribution updates are only accepted during the RAID phase.');
    }

    const playersSheet = getSheet_(SHEETS.PLAYERS);
    const values = getBodyValues_(playersSheet, HEADERS.Players.length);

    let targetIndex = -1;
    let role = '';

    let totalDamageBefore = 0;
    let totalHealingBefore = 0;
    let totalBlockedBefore = 0;

    for (let i = 0; i < values.length; i++) {
      if (String(values[i][0]) !== sessionId) {
        continue;
      }

      totalDamageBefore += number_(values[i][5]);
      totalHealingBefore += number_(values[i][6]);
      totalBlockedBefore += number_(values[i][7]);

      if (String(values[i][1]) === playerId) {
        targetIndex = i;
        role = String(values[i][2]);
      }
    }

    if (targetIndex === -1) {
      throw new Error('Player not found in this session.');
    }

    // Never trust replacement totals from the client.
    // Only role-appropriate increments are accepted.
    const accepted = validateContributionDelta_(
      role,
      incomingDamage,
      incomingHealing,
      incomingBlocked,
      incomingActions
    );

    const row = values[targetIndex];
    const newDamage = number_(row[5]) + accepted.damage_delta;
    const newHealing = number_(row[6]) + accepted.healing_delta;
    const newBlocked = number_(row[7]) + accepted.blocked_delta;
    const newActions = number_(row[8]) + accepted.actions_delta;
    const now = new Date();

    // Last_Seen, Damage, Healing, Blocked, Actions
    playersSheet.getRange(targetIndex + 2, 5, 1, 5).setValues([[
      now,
      newDamage,
      newHealing,
      newBlocked,
      newActions
    ]]);

    const totals = {
      total_damage:
        totalDamageBefore - number_(row[5]) + newDamage,
      total_healing:
        totalHealingBefore - number_(row[6]) + newHealing,
      total_blocked:
        totalBlockedBefore - number_(row[7]) + newBlocked
    };

    const bossMaxHp = number_(session.values[4]);
    const bossRemaining = Math.max(0, bossMaxHp - totals.total_damage);

    let phase = String(session.values[1]);

    // The first contribution request that reduces boss HP to 0
    // advances the session to LOOT.
    if (bossRemaining <= 0 && phase === PHASES.RAID) {
      const sessionsSheet = getSheet_(SHEETS.SESSIONS);
      sessionsSheet.getRange(session.row, 2).setValue(PHASES.LOOT);
      phase = PHASES.LOOT;
    }

    return {
      ok: true,
      session_id: sessionId,
      player_id: playerId,
      role: role,
      accepted: accepted,
      player_totals: {
        damage: newDamage,
        healing: newHealing,
        blocked: newBlocked,
        actions: newActions
      },
      session_totals: totals,
      boss_hp_remaining: bossRemaining,
      phase: phase
    };

  } finally {
    lock.releaseLock();
  }
}


function submitVote_(body) {
  const sessionId = normalizeSessionId_(body.session_id);
  const playerId = String(body.player_id || '').trim();
  const lootVote = String(body.loot_vote || '').trim().toUpperCase();
  const systemVote = String(body.system_vote || '').trim().toUpperCase();

  if (!playerId) {
    throw new Error('Missing player_id.');
  }

  if (VALID_LOOT_VOTES.indexOf(lootVote) === -1) {
    throw new Error('loot_vote must be one of: A, B, C, D, E.');
  }

  if (VALID_SYSTEM_VOTES.indexOf(systemVote) === -1) {
    throw new Error('system_vote must be YES or NO.');
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const session = findSessionRecord_(sessionId);
    if (!session) {
      throw new Error('Session not found.');
    }

    const player = findPlayerRecord_(sessionId, playerId);
    if (!player) {
      throw new Error('Player not found in this session.');
    }

    const votesSheet = getSheet_(SHEETS.VOTES);
    const voteValues = getBodyValues_(votesSheet, HEADERS.Votes.length);

    for (let i = 0; i < voteValues.length; i++) {
      if (
        String(voteValues[i][0]) === sessionId &&
        String(voteValues[i][1]) === playerId
      ) {
        return {
          ok: false,
          error: 'This player has already voted.',
          already_voted: true,
          existing_vote: {
            loot_vote: String(voteValues[i][2]),
            system_vote: String(voteValues[i][3]),
            timestamp: toIso_(voteValues[i][4])
          }
        };
      }
    }

    const now = new Date();

    votesSheet.appendRow([
      sessionId,
      playerId,
      lootVote,
      systemVote,
      now
    ]);

    // Keep Results reasonably current after each vote.
    const summary = calculateSummary_(sessionId);
    upsertResultRow_(sessionId, summary);

    return {
      ok: true,
      session_id: sessionId,
      player_id: playerId,
      loot_vote: lootVote,
      system_vote: systemVote,
      timestamp: now.toISOString()
    };

  } finally {
    lock.releaseLock();
  }
}


function setPhase_(sessionIdRaw, phaseRaw) {
  const sessionId = normalizeSessionId_(sessionIdRaw);
  const phase = String(phaseRaw || '').trim().toUpperCase();

  if (
    [
      PHASES.WAITING,
      PHASES.RAID,
      PHASES.LOOT,
      PHASES.RESULTS
    ].indexOf(phase) === -1
  ) {
    throw new Error('Invalid phase.');
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const session = findSessionRecord_(sessionId);
    if (!session) {
      throw new Error('Session not found.');
    }

    // If someone asks to move directly into RAID, initialize
    // raid timing and HP exactly like START RAID.
    if (phase === PHASES.RAID) {
      return startRaidInternalWhileLocked_(sessionId, session);
    }

    const sessionsSheet = getSheet_(SHEETS.SESSIONS);
    sessionsSheet.getRange(session.row, 2).setValue(phase);

    return {
      ok: true,
      session_id: sessionId,
      phase: phase
    };

  } finally {
    lock.releaseLock();
  }
}


function resetSession_(sessionIdRaw) {
  const sessionId = normalizeSessionId_(sessionIdRaw);

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);

  try {
    const session = findSessionRecord_(sessionId);
    if (!session) {
      throw new Error('Session not found.');
    }

    // Keep the Session ID but return it to a clean waiting-room state.
    const sessionsSheet = getSheet_(SHEETS.SESSIONS);
    sessionsSheet.getRange(session.row, 2, 1, 6).setValues([[
      PHASES.WAITING,
      session.values[2], // preserve Created_Time
      '',
      0,
      0,
      GAME.RAID_DURATION_SECONDS
    ]]);

    removeRowsForSession_(getSheet_(SHEETS.PLAYERS), sessionId, HEADERS.Players.length);
    removeRowsForSession_(getSheet_(SHEETS.VOTES), sessionId, HEADERS.Votes.length);
    removeRowsForSession_(getSheet_(SHEETS.RESULTS), sessionId, HEADERS.Results.length);

    upsertResultRow_(sessionId, {
      player_count: 0,
      total_damage: 0,
      total_healing: 0,
      total_blocked: 0,
      yes_count: 0,
      no_count: 0
    });

    return {
      ok: true,
      session_id: sessionId,
      phase: PHASES.WAITING,
      message: 'Session reset. Players and votes for this session were cleared.'
    };

  } finally {
    lock.releaseLock();
  }
}


// ============================================================
// GET ACTIONS
// ============================================================

function getSession_(sessionIdRaw) {
  const sessionId = normalizeSessionId_(sessionIdRaw);
  const session = findSessionRecord_(sessionId);

  if (!session) {
    throw new Error('Session not found.');
  }

  const summary = calculateSummary_(sessionId);
  const state = buildSessionState_(session, summary);

  return Object.assign({
    ok: true
  }, state);
}


function getPlayers_(sessionIdRaw) {
  const sessionId = normalizeSessionId_(sessionIdRaw);

  if (!findSessionRecord_(sessionId)) {
    throw new Error('Session not found.');
  }

  const playersSheet = getSheet_(SHEETS.PLAYERS);
  const values = getBodyValues_(playersSheet, HEADERS.Players.length);

  const players = [];

  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]) !== sessionId) {
      continue;
    }

    players.push({
      session_id: String(values[i][0]),
      player_id: String(values[i][1]),
      role: String(values[i][2]),
      joined_time: toIso_(values[i][3]),
      last_seen: toIso_(values[i][4]),
      damage: number_(values[i][5]),
      healing: number_(values[i][6]),
      blocked: number_(values[i][7]),
      actions: number_(values[i][8])
    });
  }

  return {
    ok: true,
    session_id: sessionId,
    player_count: players.length,
    players: players
  };
}


function getResults_(sessionIdRaw) {
  const sessionId = normalizeSessionId_(sessionIdRaw);
  const session = findSessionRecord_(sessionId);

  if (!session) {
    throw new Error('Session not found.');
  }

  const summary = calculateSummary_(sessionId);
  upsertResultRow_(sessionId, summary);

  const state = buildSessionState_(session, summary);

  return {
    ok: true,
    session: state,
    player_count: summary.player_count,
    role_counts: summary.role_counts,
    active_players: summary.active_players,

    totals: {
      damage: summary.total_damage,
      healing: summary.total_healing,
      blocked: summary.total_blocked,
      actions: summary.total_actions
    },

    leaders: {
      top_dps: summary.top_dps,
      top_healer: summary.top_healer,
      top_tank: summary.top_tank
    },

    loot_votes: summary.loot_votes,

    system_votes: {
      yes: summary.yes_count,
      no: summary.no_count,
      total: summary.yes_count + summary.no_count,
      yes_percent: percent_(summary.yes_count, summary.yes_count + summary.no_count),
      no_percent: percent_(summary.no_count, summary.yes_count + summary.no_count)
    },

    total_votes: summary.total_votes,
    last_updated: new Date().toISOString()
  };
}


// ============================================================
// CALCULATIONS
// ============================================================

function calculateSummary_(sessionId) {
  const playersSheet = getSheet_(SHEETS.PLAYERS);
  const votesSheet = getSheet_(SHEETS.VOTES);

  const playerValues = getBodyValues_(playersSheet, HEADERS.Players.length);
  const voteValues = getBodyValues_(votesSheet, HEADERS.Votes.length);

  let playerCount = 0;
  let activePlayers = 0;
  let totalDamage = 0;
  let totalHealing = 0;
  let totalBlocked = 0;
  let totalActions = 0;

  const roleCounts = {
    DPS: 0,
    HEALER: 0,
    TANK: 0
  };

  let topDps = null;
  let topHealer = null;
  let topTank = null;

  const nowMs = Date.now();
  const activeThresholdMs = 20000;

  for (let i = 0; i < playerValues.length; i++) {
    const row = playerValues[i];

    if (String(row[0]) !== sessionId) {
      continue;
    }

    playerCount++;

    const playerId = String(row[1]);
    const role = String(row[2]);
    const lastSeen = dateMs_(row[4]);
    const damage = number_(row[5]);
    const healing = number_(row[6]);
    const blocked = number_(row[7]);
    const actions = number_(row[8]);

    if (roleCounts.hasOwnProperty(role)) {
      roleCounts[role]++;
    }

    // Players who have been seen recently count as active.
    // In practice, contribution uploads update Last_Seen.
    if (lastSeen && nowMs - lastSeen <= activeThresholdMs) {
      activePlayers++;
    }

    totalDamage += damage;
    totalHealing += healing;
    totalBlocked += blocked;
    totalActions += actions;

    if (role === 'DPS') {
      if (!topDps || damage > topDps.value) {
        topDps = {
          player_id: playerId,
          value: damage
        };
      }
    }

    if (role === 'HEALER') {
      if (!topHealer || healing > topHealer.value) {
        topHealer = {
          player_id: playerId,
          value: healing
        };
      }
    }

    if (role === 'TANK') {
      if (!topTank || blocked > topTank.value) {
        topTank = {
          player_id: playerId,
          value: blocked
        };
      }
    }
  }

  const lootVotes = {
    A: 0,
    B: 0,
    C: 0,
    D: 0,
    E: 0
  };

  let yesCount = 0;
  let noCount = 0;
  let totalVotes = 0;

  for (let i = 0; i < voteValues.length; i++) {
    const row = voteValues[i];

    if (String(row[0]) !== sessionId) {
      continue;
    }

    totalVotes++;

    const loot = String(row[2]).toUpperCase();
    const system = String(row[3]).toUpperCase();

    if (lootVotes.hasOwnProperty(loot)) {
      lootVotes[loot]++;
    }

    if (system === 'YES') {
      yesCount++;
    } else if (system === 'NO') {
      noCount++;
    }
  }

  return {
    player_count: playerCount,
    active_players: activePlayers,
    role_counts: roleCounts,

    total_damage: totalDamage,
    total_healing: totalHealing,
    total_blocked: totalBlocked,
    total_actions: totalActions,

    top_dps: leaderObject_('DPS', topDps, 'damage'),
    top_healer: leaderObject_('HEALER', topHealer, 'healing'),
    top_tank: leaderObject_('TANK', topTank, 'blocked'),

    loot_votes: {
      A: voteStat_(lootVotes.A, totalVotes),
      B: voteStat_(lootVotes.B, totalVotes),
      C: voteStat_(lootVotes.C, totalVotes),
      D: voteStat_(lootVotes.D, totalVotes),
      E: voteStat_(lootVotes.E, totalVotes)
    },

    yes_count: yesCount,
    no_count: noCount,
    total_votes: totalVotes
  };
}


function buildSessionState_(session, summary) {
  const values = session.values;

  const sessionId = String(values[0]);
  const phase = String(values[1]);
  const createdTime = toIso_(values[2]);
  const startTime = toIso_(values[3]);

  const bossMaxHp = number_(values[4]);
  const raidMaxHp = number_(values[5]);
  const raidDuration = number_(values[6]) || GAME.RAID_DURATION_SECONDS;

  let elapsedSeconds = 0;

  if (startTime) {
    elapsedSeconds = Math.max(
      0,
      Math.floor((Date.now() - new Date(startTime).getTime()) / 1000)
    );
  }

  const timeRemaining = phase === PHASES.WAITING
    ? raidDuration
    : Math.max(0, raidDuration - elapsedSeconds);

  const bossHpRemaining = Math.max(
    0,
    bossMaxHp - summary.total_damage
  );

  const incomingRaidDamage = Math.floor(
    elapsedSeconds *
    summary.player_count *
    GAME.RAID_DAMAGE_PER_PLAYER_PER_SECOND
  );

  const preventedDamage =
    summary.total_healing +
    summary.total_blocked * GAME.BLOCK_MITIGATION_VALUE;

  let raidHpRemaining = raidMaxHp;

  if (phase !== PHASES.WAITING && raidMaxHp > 0) {
    raidHpRemaining = clamp_(
      raidMaxHp - incomingRaidDamage + preventedDamage,
      0,
      raidMaxHp
    );
  }

  return {
    session_id: sessionId,
    phase: phase,
    created_time: createdTime,
    start_time: startTime,

    raid_duration: raidDuration,
    elapsed_seconds: elapsedSeconds,
    time_remaining: timeRemaining,

    boss_max_hp: bossMaxHp,
    boss_hp: bossHpRemaining,
    boss_percent: bossMaxHp > 0
      ? Math.round((bossHpRemaining / bossMaxHp) * 1000) / 10
      : 100,

    raid_max_hp: raidMaxHp,
    raid_hp: raidHpRemaining,
    raid_percent: raidMaxHp > 0
      ? Math.round((raidHpRemaining / raidMaxHp) * 1000) / 10
      : 100,

    boss_defeated: bossMaxHp > 0 && bossHpRemaining <= 0,
    timed_out: phase === PHASES.RAID && timeRemaining <= 0,

    player_count: summary.player_count,
    active_players: summary.active_players,
    role_counts: summary.role_counts,

    totals: {
      damage: summary.total_damage,
      healing: summary.total_healing,
      blocked: summary.total_blocked,
      actions: summary.total_actions
    },

    game_config: publicGameConfig_()
  };
}


// ============================================================
// CONTRIBUTION VALIDATION
// ============================================================

function validateContributionDelta_(
  role,
  damageDelta,
  healingDelta,
  blockedDelta,
  actionsDelta
) {
  const accepted = {
    damage_delta: 0,
    healing_delta: 0,
    blocked_delta: 0,
    actions_delta: actionsDelta
  };

  // The browser sends accumulated deltas, not totals.
  // We still verify that the contribution is compatible with the player's role
  // and with the number of reported valid actions.

  if (role === 'DPS') {
    accepted.damage_delta = Math.min(
      damageDelta,
      actionsDelta * GAME.ATTACK_VALUE
    );
  }

  if (role === 'HEALER') {
    accepted.healing_delta = Math.min(
      healingDelta,
      actionsDelta * GAME.HEAL_VALUE
    );
  }

  if (role === 'TANK') {
    accepted.blocked_delta = Math.min(
      blockedDelta,
      actionsDelta * GAME.BLOCK_VALUE
    );
  }

  return accepted;
}


// ============================================================
// INTERNAL SESSION / PLAYER HELPERS
// ============================================================

function startRaidInternalWhileLocked_(sessionId, existingSession) {
  const session = existingSession || findSessionRecord_(sessionId);

  if (!session) {
    throw new Error('Session not found.');
  }

  const playersSheet = getSheet_(SHEETS.PLAYERS);
  const playerValues = getBodyValues_(playersSheet, HEADERS.Players.length);
  const playerCount = countPlayersForSessionFromValues_(playerValues, sessionId);

  if (playerCount < 1) {
    throw new Error('At least one player must join before the raid can start.');
  }

  const bossMaxHp = Math.max(
    GAME.MIN_BOSS_HP,
    playerCount * GAME.BOSS_HP_PER_PLAYER
  );

  const raidMaxHp = Math.max(
    GAME.MIN_RAID_HP,
    playerCount * GAME.RAID_HP_PER_PLAYER
  );

  const now = new Date();

  const sessionsSheet = getSheet_(SHEETS.SESSIONS);

  sessionsSheet.getRange(session.row, 2, 1, 6).setValues([[
    PHASES.RAID,
    session.values[2],
    now,
    bossMaxHp,
    raidMaxHp,
    GAME.RAID_DURATION_SECONDS
  ]]);

  return {
    ok: true,
    session_id: sessionId,
    phase: PHASES.RAID,
    start_time: now.toISOString(),
    player_count: playerCount,
    boss_max_hp: bossMaxHp,
    raid_max_hp: raidMaxHp,
    raid_duration: GAME.RAID_DURATION_SECONDS,
    game_config: publicGameConfig_()
  };
}


function findSessionRecord_(sessionId) {
  const sheet = getSheet_(SHEETS.SESSIONS);
  const values = getBodyValues_(sheet, HEADERS.Sessions.length);

  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]) === sessionId) {
      return {
        row: i + 2,
        values: values[i]
      };
    }
  }

  return null;
}


function findPlayerRecord_(sessionId, playerId) {
  const sheet = getSheet_(SHEETS.PLAYERS);
  const values = getBodyValues_(sheet, HEADERS.Players.length);

  for (let i = 0; i < values.length; i++) {
    if (
      String(values[i][0]) === sessionId &&
      String(values[i][1]) === playerId
    ) {
      return {
        row: i + 2,
        values: values[i]
      };
    }
  }

  return null;
}


function generateUniqueSessionId_(sessionsSheet) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const values = getBodyValues_(sessionsSheet, HEADERS.Sessions.length);
  const existing = {};

  for (let i = 0; i < values.length; i++) {
    existing[String(values[i][0])] = true;
  }

  for (let attempt = 0; attempt < 100; attempt++) {
    let suffix = '';

    for (let i = 0; i < 4; i++) {
      suffix += chars.charAt(
        Math.floor(Math.random() * chars.length)
      );
    }

    const candidate = 'RAID-' + suffix;

    if (!existing[candidate]) {
      return candidate;
    }
  }

  // Extremely unlikely fallback.
  return 'RAID-' + Utilities.getUuid().replace(/-/g, '').slice(0, 8).toUpperCase();
}


function nextPlayerIdFromValues_(values, sessionId) {
  let maxNumber = 0;

  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]) !== sessionId) {
      continue;
    }

    const playerId = String(values[i][1]);
    const match = playerId.match(/^Raider A(\d+)$/);

    if (match) {
      maxNumber = Math.max(maxNumber, Number(match[1]));
    }
  }

  const next = maxNumber + 1;

  return 'Raider A' + String(next).padStart(2, '0');
}


function chooseBalancedRoleFromValues_(values, sessionId) {
  const counts = {
    DPS: 0,
    HEALER: 0,
    TANK: 0
  };

  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]) !== sessionId) {
      continue;
    }

    const role = String(values[i][2]);

    if (counts.hasOwnProperty(role)) {
      counts[role]++;
    }
  }

  const minimum = Math.min(
    counts.DPS,
    counts.HEALER,
    counts.TANK
  );

  const candidates = ROLES.filter(function(role) {
    return counts[role] === minimum;
  });

  return candidates[
    Math.floor(Math.random() * candidates.length)
  ];
}


function countPlayersForSessionFromValues_(values, sessionId) {
  let count = 0;

  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]) === sessionId) {
      count++;
    }
  }

  return count;
}


// ============================================================
// RESULTS SHEET
// ============================================================

function upsertResultRow_(sessionId, summary) {
  const sheet = getSheet_(SHEETS.RESULTS);
  const values = getBodyValues_(sheet, HEADERS.Results.length);

  let rowNumber = -1;

  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]) === sessionId) {
      rowNumber = i + 2;
      break;
    }
  }

  const row = [
    sessionId,
    number_(summary.player_count),
    number_(summary.total_damage),
    number_(summary.total_healing),
    number_(summary.total_blocked),
    number_(summary.yes_count),
    number_(summary.no_count),
    new Date()
  ];

  if (rowNumber === -1) {
    sheet.appendRow(row);
  } else {
    sheet.getRange(rowNumber, 1, 1, row.length).setValues([row]);
  }
}


// ============================================================
// SHEET CREATION / STORAGE HELPERS
// ============================================================

function ensureDatabase_() {
  // Avoid four sheet-existence checks on every poll from every student.
  // The cache is only an optimization; getSheet_() still self-heals if a
  // particular sheet is missing.
  const cache = CacheService.getScriptCache();

  if (cache.get('WHO_GETS_THE_LOOT_DB_READY_V1') === '1') {
    return;
  }

  const ss = SpreadsheetApp.getActiveSpreadsheet();

  if (!ss) {
    throw new Error(
      'No active spreadsheet found. This Apps Script project must be bound to a Google Sheet.'
    );
  }

  ensureSheet_(ss, SHEETS.SESSIONS, HEADERS.Sessions);
  ensureSheet_(ss, SHEETS.PLAYERS, HEADERS.Players);
  ensureSheet_(ss, SHEETS.VOTES, HEADERS.Votes);
  ensureSheet_(ss, SHEETS.RESULTS, HEADERS.Results);

  cache.put('WHO_GETS_THE_LOOT_DB_READY_V1', '1', 21600);
}


function ensureSheet_(ss, name, headers) {
  let sheet = ss.getSheetByName(name);

  if (!sheet) {
    sheet = ss.insertSheet(name);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    sheet.autoResizeColumns(1, headers.length);
    return sheet;
  }

  // Only write headers when row 1 is blank.
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
  }

  return sheet;
}


function getSheet_(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  if (!ss) {
    throw new Error('No active spreadsheet found.');
  }

  let sheet = ss.getSheetByName(name);

  if (!sheet) {
    const headers = HEADERS[name];

    if (!headers) {
      throw new Error('Unknown sheet: ' + name);
    }

    sheet = ensureSheet_(ss, name, headers);
  }

  return sheet;
}


function getBodyValues_(sheet, width) {
  const lastRow = sheet.getLastRow();

  if (lastRow < 2) {
    return [];
  }

  return sheet
    .getRange(2, 1, lastRow - 1, width)
    .getValues();
}


function removeRowsForSession_(sheet, sessionId, width) {
  const values = getBodyValues_(sheet, width);

  if (values.length === 0) {
    return;
  }

  const retained = values.filter(function(row) {
    return String(row[0]) !== sessionId;
  });

  sheet
    .getRange(2, 1, values.length, width)
    .clearContent();

  if (retained.length > 0) {
    sheet
      .getRange(2, 1, retained.length, width)
      .setValues(retained);
  }
}


// ============================================================
// SMALL UTILITY HELPERS
// ============================================================

function publicGameConfig_() {
  return {
    raid_duration_seconds: GAME.RAID_DURATION_SECONDS,
    attack_value: GAME.ATTACK_VALUE,
    heal_value: GAME.HEAL_VALUE,
    block_value: GAME.BLOCK_VALUE,
    click_cooldown_ms: GAME.CLICK_COOLDOWN_MS,
    contribution_upload_ms: GAME.CONTRIBUTION_UPLOAD_MS,
    student_poll_ms: GAME.STUDENT_POLL_MS,
    host_poll_ms: GAME.HOST_POLL_MS
  };
}


function normalizeSessionId_(value) {
  const sessionId = String(value || '').trim().toUpperCase();

  if (!sessionId) {
    throw new Error('Missing session_id.');
  }

  if (!/^RAID-[A-Z0-9]{4,8}$/.test(sessionId)) {
    throw new Error('Invalid session_id format.');
  }

  return sessionId;
}


function nonNegativeInteger_(value) {
  const n = Number(value);

  if (!isFinite(n) || n <= 0) {
    return 0;
  }

  return Math.floor(n);
}


function number_(value) {
  const n = Number(value);
  return isFinite(n) ? n : 0;
}


function clamp_(value, min, max) {
  return Math.max(min, Math.min(max, value));
}


function percent_(count, total) {
  if (!total) {
    return 0;
  }

  return Math.round((count / total) * 1000) / 10;
}


function voteStat_(count, totalVotes) {
  return {
    count: count,
    percent: percent_(count, totalVotes)
  };
}


function leaderObject_(role, leader, metric) {
  if (!leader) {
    return {
      role: role,
      player_id: null,
      metric: metric,
      value: 0
    };
  }

  return {
    role: role,
    player_id: leader.player_id,
    metric: metric,
    value: leader.value
  };
}


function toIso_(value) {
  if (!value) {
    return null;
  }

  if (Object.prototype.toString.call(value) === '[object Date]') {
    return value.toISOString();
  }

  const d = new Date(value);

  if (isNaN(d.getTime())) {
    return String(value);
  }

  return d.toISOString();
}


function dateMs_(value) {
  if (!value) {
    return 0;
  }

  const d = new Date(value);
  const ms = d.getTime();

  return isNaN(ms) ? 0 : ms;
}


function safeError_(err) {
  if (!err) {
    return 'Unknown error.';
  }

  if (err.message) {
    return String(err.message);
  }

  return String(err);
}


function jsonResponse_(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
