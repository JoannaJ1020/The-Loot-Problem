# WHO GETS THE LOOT?

A classroom multiplayer web activity designed to introduce the problem of distributing scarce rewards after a cooperative raid.

The activity deliberately **does not explain DKP**. The instructor can introduce DKP after the class has experienced the reward-allocation problem.

## Files

- `index.html` — student game
- `host.html` — instructor dashboard and projected results
- `config.js` — contains the Google Apps Script Web App URL
- `Code.gs` — Google Apps Script backend
- `README.md` — setup instructions

## Current backend URL

Your `config.js` is already configured with:

`https://script.google.com/macros/s/AKfycbxDlgUluEMpPaTxEx5nkPoufxfwW2cD0beHiY9dVDsmLQFBHgACwn8FQAg3H-qm3-XO/exec`

If you redeploy Apps Script later and receive a different `/exec` URL, update `config.js`.

---

# Part 1 — Create the Google Sheet database

1. Open Google Sheets.
2. Create one blank spreadsheet.
3. Give it a recognizable name such as **Who Gets the Loot Data**.
4. You do not need to create the tabs manually.

The Apps Script backend automatically creates these tabs:

- `Sessions`
- `Players`
- `Votes`
- `Results`

Do not rename these tabs after setup.

---

# Part 2 — Add the Apps Script backend

1. In the Google Sheet, click **Extensions → Apps Script**.
2. Apps Script opens in a new tab.
3. Open the default `Code.gs`.
4. Delete the default sample code.
5. Copy all code from this repository's `Code.gs`.
6. Paste it into Apps Script.
7. Click **Save**.

## Run the one-time setup

1. At the top of Apps Script, choose the function `setupDatabase`.
2. Click **Run**.
3. Google will ask for permission the first time.
4. Complete the authorization flow.
5. Return to the spreadsheet.
6. Confirm that these four tabs now exist:
   - Sessions
   - Players
   - Votes
   - Results

---

# Part 3 — Deploy Apps Script as a Web App

1. In Apps Script, click **Deploy → New deployment**.
2. Click the gear icon and choose **Web app**.
3. Set **Execute as** to **Me**.
4. Set **Who has access** to **Anyone**.
5. Click **Deploy**.
6. Complete authorization if prompted.
7. Copy the Web App URL.

It should end in `/exec`.

Your current deployment URL is already placed in `config.js`.

## Optional backend test

Open this URL in a browser:

`https://script.google.com/macros/s/AKfycbxDlgUluEMpPaTxEx5nkPoufxfwW2cD0beHiY9dVDsmLQFBHgACwn8FQAg3H-qm3-XO/exec?action=ping`

A working deployment should return JSON containing `"ok": true`.

If it says authorization is required or access is denied, check the Web App deployment settings.

---

# Part 4 — Create a GitHub repository

1. Go to GitHub.
2. Click **New repository**.
3. Use a name such as `who-gets-the-loot`.
4. Make the repository **Public** if you want the easiest GitHub Pages setup.
5. Create the repository.

Upload these files to the repository root:

- `index.html`
- `host.html`
- `config.js`
- `README.md`

`Code.gs` can also be stored in the repository for backup/documentation. It is not used directly by GitHub Pages.

Important: keep `index.html`, `host.html`, and `config.js` in the same folder.

---

# Part 5 — Turn on GitHub Pages

1. Open the GitHub repository.
2. Click **Settings**.
3. Click **Pages**.
4. Under **Build and deployment**, choose:
   - Source: **Deploy from a branch**
   - Branch: `main`
   - Folder: `/ (root)`
5. Click **Save**.

After Pages is published, your student page will be similar to:

`https://YOUR-USERNAME.github.io/who-gets-the-loot/`

The instructor page will be:

`https://YOUR-USERNAME.github.io/who-gets-the-loot/host.html`

The host automatically generates student links in this form:

`index.html?session=RAID-A7K2`

and creates a QR code pointing directly to that session.

---

# Part 6 — How to run the classroom activity

## Instructor

1. Open `host.html` on the classroom computer.
2. Project that browser tab.
3. Click **NEW SESSION**.
4. A Session ID such as `RAID-A7K2` appears.
5. A QR code appears.
6. Students scan the QR code.
7. Watch the player count and role counts increase.
8. When the class is ready, click **START RAID**.

## Students

Students do not enter names.

Each student is automatically assigned:

- an anonymous ID such as `Raider A01`
- one role:
  - DPS
  - HEALER
  - TANK

The assignment is balanced approximately evenly across the class.

## During the raid

The raid lasts approximately 60 seconds.

DPS students receive an **ATTACK** button.

HEALER students receive a **HEAL** button.

TANK students receive a **BLOCK** button. Approximately every 8–12 seconds, tank screens display a short warning window:

**BOSS ATTACK INCOMING!**

The game does not send one network request for every tap.

Each browser accumulates actions locally and uploads contribution deltas approximately every 3 seconds.

If an upload fails, the pending contribution remains in the browser and is retried on a later upload.

---

# Part 7 — Loot voting

After the raid ends, students see only three fictional loot items:

- Blade of the Fallen King
- Guardian's Aegis
- Crystal of Renewal

They answer:

**WHO SHOULD GET THE LOOT?**

Choices:

A. Random lottery among everyone  
B. Players who dealt the most damage  
C. Players who helped the team the most  
D. Players who contributed the most time and effort  
E. We need a system that measures different kinds of contribution

Then students answer:

**Before the next raid, should the group agree on a clear reward system?**

- YES
- NO

Each Player ID can vote only once.

---

# Part 8 — Host results

The host dashboard displays three separate contribution leaders:

- Top DPS
- Top Healer
- Top Tank

It intentionally does **not** calculate a universal contribution score and does not identify one overall "best player."

The projected screen then asks:

**WHO CONTRIBUTED THE MOST?**

**There is no single obvious answer.**

The dashboard also shows:

- class loot vote
- vote counts
- percentages
- YES/NO result for agreeing on a reward system

The final prompt is:

> Different players contributed different things.  
> How can a guild turn contribution into a fair, measurable reward system?

The game itself does not reveal or explain DKP.

---

# Part 9 — Reset before another class

There are two different controls:

## RESET SESSION

Keeps the current Session ID but clears:

- players
- votes
- contribution totals

and returns the session to the waiting room.

Use this if you want to test again without generating a new QR code.

## NEW SESSION

Creates a completely new Session ID.

Use this before a new classroom group if you want a clean new code and QR link.

---

# Part 10 — Test before class

Use at least two or three devices.

Recommended test:

1. Open `host.html` on a computer.
2. Click **NEW SESSION**.
3. Join on a phone.
4. Join in another browser/private window.
5. Confirm each device gets a different anonymous Raider ID.
6. Confirm roles are assigned.
7. Click **START RAID**.
8. Press the role buttons.
9. Confirm the host totals rise.
10. Wait for the raid to end.
11. Vote on each student device.
12. Confirm the host results update.

For a larger test, open several private/incognito windows or use several devices.

---

# Important technical notes

## Google Apps Script / Google Sheets

The backend uses `SpreadsheetApp.getActiveSpreadsheet()` and therefore must be bound to the spreadsheet through **Extensions → Apps Script**.

## Content-Type

Frontend POST requests use:

`Content-Type: text/plain`

This matches the Apps Script backend and helps avoid unnecessary CORS preflight requests.

## LockService

The backend uses `LockService` for shared writes, including:

- assigning anonymous Player IDs
- contribution updates
- session changes

This helps avoid duplicate IDs and conflicting simultaneous writes.

## Contribution security

The frontend sends **deltas**, not trusted lifetime totals.

Example:

```json
{
  "action": "update_contribution",
  "session_id": "RAID-A7K2",
  "player_id": "Raider A12",
  "damage_delta": 20,
  "healing_delta": 0,
  "blocked_delta": 0,
  "actions_delta": 2
}
```

The server adds accepted deltas to the existing spreadsheet totals.

## Refresh behavior

Student identity is saved in browser `localStorage`:

- `session_id`
- `player_id`
- `role`

Refreshing the page attempts to reconnect using the same Player ID instead of creating a second player.

## Polling

Approximate intervals:

- host state: every 2 seconds
- student state: every 3.5 seconds
- contribution upload: every 3 seconds

These values prioritize reliability over true real-time networking.

---

# If something does not work

## Students see a connection error

Check:

1. `config.js` contains the correct Apps Script `/exec` URL.
2. Apps Script deployment access is **Anyone**.
3. You deployed the latest Apps Script version.
4. You are opening the frontend from GitHub Pages, not from a restricted preview environment.

## Apps Script code changed but behavior did not change

Apps Script deployments can continue serving an older version after code changes.

Go to:

**Deploy → Manage deployments → Edit**

Select a new version and redeploy.

Then keep the new `/exec` URL in `config.js` if Google gives you a different one.

## QR code does not appear

The host page uses a public QR-code JavaScript library loaded from a CDN.

The student join URL is also printed directly below the QR code, so students can still open/copy the URL if the QR library is unavailable.

## Chart does not appear

The host results chart uses Chart.js from a CDN.

The underlying vote data remains in Google Sheets even if the chart library fails to load.

---

# Classroom design note

The activity is intentionally built around ambiguity:

- damage matters
- healing matters
- blocking matters
- time and effort may matter
- only three rewards exist

The software stops before prescribing the solution. The next instructional slide can introduce the reward system you want students to discuss.
