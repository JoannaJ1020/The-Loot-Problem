// WHO GETS THE LOOT? — frontend configuration
// Your deployed Google Apps Script Web App URL:
const CONFIG = Object.freeze({
  API_URL: "https://script.google.com/macros/s/AKfycbxDlgUluEMpPaTxEx5nkPoufxfwW2cD0beHiY9dVDsmLQFBHgACwn8FQAg3H-qm3-XO/exec"
});
